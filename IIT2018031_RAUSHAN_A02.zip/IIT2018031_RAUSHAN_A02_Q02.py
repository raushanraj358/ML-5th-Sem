import pandas as ps
import numpy as nm
from treelib import Node, Tree
sve =0

# Define the calculate entropy function
def calculate_entropy(vs_label):
    classes, class_counts = nm.unique(vs_label, return_counts=True)
    entropy_value = nm.sum(
        [(-class_counts[i] / nm.sum(class_counts)) * nm.log2(class_counts[i] / nm.sum(class_counts)) for i in
         range(len(classes))])
    return entropy_value

# Define the calculate information gain function
def calculate_information_gain(dataset, feature, label):
    # Calculate the dataset entropy
    dataset_entropy = calculate_entropy(dataset[label])
    values, feat_counts = nm.unique(dataset[feature], return_counts=True)

    # Calculate the weighted feature entropy                                # Call the calculate_entropy function
    weighted_feature_entropy = nm.sum([(feat_counts[i] / nm.sum(feat_counts)) * calculate_entropy(
        dataset.where(dataset[feature] == values[i]).dropna()[label]) for i in range(len(values))])
    feature_info_gain = dataset_entropy - weighted_feature_entropy
    return feature_info_gain

def create_decision_tree(dataset, vs, features, label, parent):
    datum = nm.unique(vs[label], return_counts=True)
    unique_data = nm.unique(dataset[label])

    if len(unique_data) <= 1:
        return unique_data[0]
    elif len(dataset) == 0:
        return unique_data[nm.argmax(datum[1])]
    elif len(features) == 0:
        return parent
    else:
        parent = unique_data[nm.argmax(datum[1])]
        # Call the calculate_information_gain function
        item_values = [calculate_information_gain(dataset, feature, label) for feature in features]

        optimum_feature_sveex = nm.argmax(item_values)
        optimum_feature = features[optimum_feature_sveex]
        decision_tree = {optimum_feature: {}}
        features = [i for i in features if i != optimum_feature]

        for value in nm.unique(dataset[optimum_feature]):
            min_data = dataset.where(dataset[optimum_feature] == value).dropna()
            # Recusrsive call to create_decision_tree function
            min_tree = create_decision_tree(min_data, vs, features, label, parent)
            decision_tree[optimum_feature][value] = min_tree
        return (decision_tree)

def predict_diabetes(test_data, decision_tree):
    for nodes in decision_tree.keys():
        value = test_data[nodes]
        decision_tree = decision_tree[nodes][value]

        prediction = "no"
        if type(decision_tree) is dict:
            prediction = predict_diabetes(test_data, decision_tree)
        else:
            prediction = decision_tree
            break
    return prediction

def loopdict(dict_, parentVar, tree):
    global sve
    for key in list(dict_):
        value = dict_[key]
        temp = str(key) + str(sve)
        sve += 1
        if parentVar is None:
            tree.create_node(str(key), temp)
            added.add(str(key))
            dict_.pop(key)
        else:
            tree.create_node(str(key), temp, parent=parentVar)
            added.add(str(key))
            dict_.pop(key)
        if isinstance(value, dict):
            parentVar = temp
            tree = loopsict(value, parentVar, tree)
        else:
            tree.create_node(str(value), str(value) + str(sve), parent=temp)
            sve += 1
    return tree


# Load the data
titanic = 'Social_Network_Ads.csv'
vs = ps.read_csv(titanic, error_bad_lines=False)
features = vs.columns[:-1]
label = 'Purchased'
parent = None
decision_tree = create_decision_tree(vs, vs, features, label, parent)

total = len(vs)
correct = 0
for index, row in vs.iterrows():
    sample_data = {'Age': row[0], 'EstimatedSalary': row[1]}
    test_data = ps.Series(sample_data)
    prediction = predict_diabetes(test_data, decision_tree)
    if prediction == row[2]:
        correct += 1

dict_ = decision_tree
added = set()
tree = Tree()
parentVar = None
tree = loopdict(dict_, parentVar, tree)
tree.show()

print("Accuracy = ", (correct / total) * 100)

