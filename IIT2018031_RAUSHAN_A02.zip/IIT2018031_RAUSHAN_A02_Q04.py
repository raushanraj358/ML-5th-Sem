import pandas as ps
import numpy as nm
from treelib import Node, Tree
import re
sve =0

# Define the calculate entropy function
def calculate_entropy(df_label):
    classes,class_counts = nm.unique(df_label,return_counts = True)
    entropy_value = nm.sum([(-class_counts[i]/nm.sum(class_counts))*nm.log2(class_counts[i]/nm.sum(class_counts)) 
                        for i in range(len(classes))])
    return entropy_value

# Define the calculate information gain function
def calculate_information_gain(dataset,feature,label): 
    # Calculate the dataset entropy
    dataset_entropy = calculate_entropy(dataset[label])   
    values,feat_counts= nm.unique(dataset[feature],return_counts=True)
    
    # Calculate the weighted feature entropy                                # Call the calculate_entropy function
    weighted_feature_entropy = nm.sum([(feat_counts[i]/nm.sum(feat_counts))*calculate_entropy(dataset.where(dataset[feature]
                              ==values[i]).dropna()[label]) for i in range(len(values))])    
    feature_info_gain = dataset_entropy - weighted_feature_entropy
    return feature_info_gain

#Define the create decision tree function
def create_decision_tree(dataset, df, features, label, parent):
    
    datum = nm.unique(df[label], return_counts = True)
    unique_data = nm.unique(dataset[label])
    
    if len(unique_data) <=1:
        return unique_data[0]
    elif len(dataset) == 0:
        return unique_data[nm.argmax(datum[1])]
    elif len(features) == 0:
        return parent
    else:
        parent = unique_data[nm.argmax([datum[1]])]
        
        item_values = [calculate_information_gain(dataset, feature, label) for feature in features]
        
        optimum_feature_sveex = nm.argmax(item_values)
        optimum_feature = features[optimum_feature_sveex]
        decision_tree = {optimum_feature:{}}
        features = [i for i in features if i != optimum_feature]
        
        for value in nm.unique(dataset[optimum_feature]):
            min_data = dataset.where(dataset[optimum_feature] == value).dropna()
            
            min_tree = create_decision_tree(min_data, df, features, label, parent)
            
            decision_tree[optimum_feature][value] = min_tree
            
        return(decision_tree)

def predict_survived(test_data, decision_tree):
    
    for nodes in decision_tree.keys():
        value = test_data[nodes]
        decision_tree = decision_tree[nodes][value]

        prediction = "0"
        if type(decision_tree) is dict:
            prediction = predict_survived(test_data, decision_tree)
        else:
            prediction = decision_tree
            break
    return prediction

def loopdict(dict_, parentVar, tree):
    
    global sve

    for key in list(dict_):
        value = dict_[key]
        if True: 
            temp = key + str(sve)
            sve += 1
            if parentVar is None:
                tree.create_node(key, temp)
                added.add(key)
                dict_.pop(key)
            else:
                tree.create_node(key, temp, parent=parentVar)
                added.add(key)
                dict_.pop(key)
            if isinstance(value, dict):
                parentVarNew = temp
                tree = loopsict(value, parentVarNew, tree)
            else:
                tree.create_node(value, value + str(sve), parent=temp)
                sve += 1
    return tree

train = ps.read_csv('titanic_train.csv')
test = ps.read_csv('titanic_test.csv')

original_train = train.copy()

full_data = [train, test]

# Feature that tells whether a passenger had a cabin on the Titanic
train['Has_Cabin'] = train["Cabin"].apply(lambda x: 0 if type(x) == float else 1)
test['Has_Cabin'] = test["Cabin"].apply(lambda x: 0 if type(x) == float else 1)

# Create new feature FamilySize as a combination of SibSp and Parch
for dataset in full_data:
    dataset['FamilySize'] = dataset['SibSp'] + dataset['Parch'] + 1
# Create new feature IsAlone from FamilySize
for dataset in full_data:
    dataset['IsAlone'] = 0
    dataset.loc[dataset['FamilySize'] == 1, 'IsAlone'] = 1
# Remove all NULLS in the Embarked column
for dataset in full_data:
    dataset['Embarked'] = dataset['Embarked'].fillna('S')
# Remove all NULLS in the Fare column
for dataset in full_data:
    dataset['Fare'] = dataset['Fare'].fillna(train['Fare'].median())

# Remove all NULLS in the Age column
for dataset in full_data:
    age_avg = dataset['Age'].mean()
    age_std = dataset['Age'].std()
    age_null_count = dataset['Age'].isnull().sum()
    age_null_random_list = nm.random.randint(age_avg - age_std, age_avg + age_std, size=age_null_count)
    # Next line has been improved to avoid warning
    dataset.loc[nm.isnan(dataset['Age']), 'Age'] = age_null_random_list
    dataset['Age'] = dataset['Age'].astype(int)

# Define function to extract titles from passenger names
def get_title(name):
    title_search = re.search(' ([A-Za-z]+)\.', name)
    # If the title exists, extract and return it.
    if title_search:
        return title_search.group(1)
    return ""

for dataset in full_data:
    dataset['Title'] = dataset['Name'].apply(get_title)
# Group all non-common titles into one single grouping "Rare"
for dataset in full_data:
    dataset['Title'] = dataset['Title'].replace(['Lady', 'Countess','Capt', 'Col','Don', 'Dr', 'Major', 'Rev', 'Sir', 'Jonkheer', 'Dona'], 'Rare')

    dataset['Title'] = dataset['Title'].replace('Mlle', 'Miss')
    dataset['Title'] = dataset['Title'].replace('Ms', 'Miss')
    dataset['Title'] = dataset['Title'].replace('Mme', 'Mrs')

for dataset in full_data:
    # Mapping Sex
    dataset['Sex'] = dataset['Sex'].map( {'female': 0, 'male': 1} ).astype(int)
    
    # Mapping titles
    title_mapping = {"Mr": 1, "Master": 2, "Mrs": 3, "Miss": 4, "Rare": 5}
    dataset['Title'] = dataset['Title'].map(title_mapping)
    dataset['Title'] = dataset['Title'].fillna(0)

    # Mapping Embarked
    dataset['Embarked'] = dataset['Embarked'].map( {'S': 0, 'C': 1, 'Q': 2} ).astype(int)
    
    # Mapping Fare
    dataset.loc[ dataset['Fare'] <= 7.91, 'Fare'] 						        = 0
    dataset.loc[(dataset['Fare'] > 7.91) & (dataset['Fare'] <= 14.454), 'Fare'] = 1
    dataset.loc[(dataset['Fare'] > 14.454) & (dataset['Fare'] <= 31), 'Fare']   = 2
    dataset.loc[ dataset['Fare'] > 31, 'Fare'] 							        = 3
    dataset['Fare'] = dataset['Fare'].astype(int)
    
    # Mapping Age
    dataset.loc[ dataset['Age'] <= 16, 'Age'] 					       = 0
    dataset.loc[(dataset['Age'] > 16) & (dataset['Age'] <= 32), 'Age'] = 1
    dataset.loc[(dataset['Age'] > 32) & (dataset['Age'] <= 48), 'Age'] = 2
    dataset.loc[(dataset['Age'] > 48) & (dataset['Age'] <= 64), 'Age'] = 3
    dataset.loc[ dataset['Age'] > 64, 'Age'] ;

drop_elements = ['PassengerId', 'Name', 'Ticket', 'Cabin', 'SibSp']
train = train.drop(drop_elements, axis = 1)
test  = test.drop(drop_elements, axis = 1)

train = train.resveex(columns = (list([a for a in train.columns if a != 'Survived']) + ['Survived']))
test = test.resveex(columns = (list([a for a in test.columns if a != 'Survived']) + ['Survived']))

features = train.columns[:-1]
label = 'Survived'
parent=None

train[label] = train[label].apply(str)
for i in range(len(features)):
    train[features[i]] = train[features[i]].apply(str)
    test[features[i]] = test[features[i]].apply(str)

decision_tree = create_decision_tree(train,train,features,label,parent)

total = len(train)
correct = 0

for index,row in train.iterrows():
    sample_data = {'pclass':row[0],'age':row[1],'sex':row[2]}
    sample_data = dict(zip(features, row[:-1]))
    test_data = ps.Series(sample_data)
    prediction = predict_survived(test_data,decision_tree)
    if(prediction == row[-1]):
        correct += 1

dict_ = decision_tree
added = set()
tree = Tree()
parentVar = None
tree = loopdict(dict_, parentVar, tree)
tree.show()

print("accuracy percentage ", (correct/total)*100)