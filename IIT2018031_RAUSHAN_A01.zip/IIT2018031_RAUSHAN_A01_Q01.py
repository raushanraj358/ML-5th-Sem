{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "metadata": {},
   "outputs": [],
   "source": [
    "import numpy as nm\n",
    "import pandas as ps\n",
    "from sklearn.model_selection import train_test_split\n",
    "import math\n",
    "from sklearn.metrics import accuracy_score\n",
    "\n",
    "#Read the csv file\n",
    "df = ps.read_csv('spam_or_not_spam.csv')\n",
    "\n",
    "#Preprocessing\n",
    "#Convert emails to string\n",
    "emails = []\n",
    "labels = []\n",
    "for i in range(len(df)):\n",
    "    emails.append(str(df['email'][i]))\n",
    "    labels.append(df['label'][i])\n",
    "\n",
    "#Make a set of all words present in the file    \n",
    "words = set()\n",
    "for email in emails:\n",
    "    words.update([a for a in email.split()])\n",
    "\n",
    "#Make a dictionary assigning an index to each word in the set\n",
    "dictionary = {}\n",
    "idx = 0\n",
    "for word in words:\n",
    "    dictionary[word] = idx\n",
    "    idx = idx + 1\n",
    "    \n",
    "#Make vectors according to information given in question\n",
    "dataset = nm.zeros((len(emails),len(dictionary)+1),int)\n",
    "for i in range(len(emails)):\n",
    "    if emails[i] == ' ':\n",
    "        dataset[i][len(dictionary)] = 1 #Empty message (last element of the vector is 1)\n",
    "        continue\n",
    "    for st in emails[i].split():\n",
    "        dataset[i][dictionary[st]] = dataset[i][dictionary[st]]+1 #Store the counts of words in vector"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {},
   "outputs": [],
   "source": [
    "#Split the dataset into training dataset and testing dataset\n",
    "X_train,X_test,y_train,y_test = train_test_split(dataset,nm.array(labels),test_size=0.2)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "metadata": {},
   "outputs": [],
   "source": [
    "#KNNClassifier\n",
    "class KNNClassifier():\n",
    "    def __init__(self,k=1):\n",
    "        self.k = k\n",
    "        \n",
    "    #Training the classifier (KNN training includes only storage of dataset)    \n",
    "    def fit(self,X_train,y_train):\n",
    "        self.X_train = X_train\n",
    "        self.y_train = y_train\n",
    "        \n",
    "    #Make predictions    \n",
    "    def predict(self,X_test):\n",
    "        y_predict = []\n",
    "        for i in range(len(X_test)):\n",
    "            y_predict.append(self.__classify(X_test[i]))\n",
    "        return y_predict\n",
    "    \n",
    "    #A utility to for predictions (Calculations of cosine similarity and choosing k nearest neighbours and assigning label in done by this function)\n",
    "    def __classify(self,instance):\n",
    "        lstsim = [] #List to store similarity with each vector in training data\n",
    "        sqrt1 = math.sqrt(nm.dot(instance,instance))\n",
    "        for i in range(len(self.X_train)):\n",
    "            sqrt2 = math.sqrt(nm.dot(self.X_train[i],self.X_train[i]))\n",
    "            sop = nm.dot(instance,self.X_train[i])\n",
    "            simil = sop/(sqrt1*sqrt2) #Similarity calculation                       \n",
    "            lstsim.append((-1*simil,self.y_train[i]))\n",
    "        lstsim.sort()\n",
    "        c0 = c1 = 0\n",
    "        #Selection of k nearest neighbours and assigning label based on majority vote\n",
    "        for i in range(self.k):\n",
    "            if lstsim[i][1] == 0:\n",
    "                c0 = c0+1\n",
    "            if lstsim[i][1] == 1:\n",
    "                c1 = c1+1\n",
    "        if c1>c0:\n",
    "            return 1\n",
    "        else:\n",
    "            return 0"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Accuracy score for k = 1 is 93.83333333333333\n",
      "Accuracy score for k = 3 is 91.83333333333333\n",
      "Accuracy score for k = 5 is 90.83333333333333\n",
      "Accuracy score for k = 19 is 93.0\n"
     ]
    }
   ],
   "source": [
    "K = [1,3,5,19]\n",
    "for i in K:\n",
    "    clf = KNNClassifier(k=i) #Instantiate the classifier\n",
    "    clf.fit(X_train,y_train) #Train the classifier\n",
    "    y_pred = clf.predict(X_test) #Make Prediction\n",
    "    print(\"Accuracy score for k =\",i,\"is\",accuracy_score(y_test,y_pred)*100) #Print Accuracy Score"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.3"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
